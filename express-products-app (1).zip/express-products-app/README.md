# Express Products App (Backend + Styled Frontend)

## What is included
- `server.js` - Express backend with endpoints that read/write `products.json`
- `products.json` - initial sample data
- `public/` - frontend files (index.html, style.css, script.js)
- `package.json` - project metadata and scripts

## How to run
1. Extract the zip and open the folder in VS Code.
2. Install dependencies:
   ```
   npm install
   ```
3. Start the server:
   ```
   npm start
   ```
   or (if you have nodemon):
   ```
   npm run dev
   ```
4. Open `http://localhost:3000` in your browser.
