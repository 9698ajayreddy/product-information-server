const $ = selector => document.querySelector(selector);
const tbody = document.querySelector('#productsTable tbody');
const nameInput = $('#name');
const priceInput = $('#price');
const inStockInput = $('#inStock');
const addBtn = $('#addBtn');
const showAll = $('#showAll');
const showInStock = $('#showInStock');

async function fetchProducts(path='/products') {
  try {
    const res = await fetch(path);
    if (!res.ok) throw new Error('Network response was not ok');
    return await res.json();
  } catch (err) {
    console.error(err);
    alert('Failed to fetch products: ' + err.message);
    return [];
  }
}

function render(products) {
  tbody.innerHTML = '';
  if (products.length === 0) {
    tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#9aa6bf;padding:18px">No products found</td></tr>';
    return;
  }
  products.forEach(p => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${p.id}</td>
      <td>${escapeHtml(p.name)}</td>
      <td>₹ ${Number(p.price).toLocaleString()}</td>
      <td><span class="pill ${p.inStock? 'in-stock':'out-stock'}">${p.inStock? 'In stock':'Out of stock'}</span></td>
      <td>
        <button class="action-btn" data-id="${p.id}" data-action="toggle">${p.inStock? 'Mark out':'Mark in'}</button>
        <button class="action-btn" data-id="${p.id}" data-action="delete">Delete</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

function escapeHtml(unsafe) {
  return unsafe
       .replace(/&/g, "&amp;")
       .replace(/</g, "&lt;")
       .replace(/>/g, "&gt;")
       .replace(/"/g, "&quot;")
       .replace(/'/g, "&#039;");
}

// Load all products initially
async function loadAll() {
  const products = await fetchProducts('/products');
  render(products);
}

async function loadInStock() {
  const products = await fetchProducts('/products/instock');
  render(products);
}

addBtn.addEventListener('click', async () => {
  const name = nameInput.value.trim();
  const price = Number(priceInput.value);
  const inStock = inStockInput.checked;
  if (!name) { alert('Please enter a product name'); return; }
  if (!price || price <= 0) { alert('Please enter a valid price'); return; }
  try {
    const res = await fetch('/products', {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ name, price, inStock })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to add');
    }
    const added = await res.json();
    nameInput.value = '';
    priceInput.value = '';
    inStockInput.checked = true;
    loadAll();
  } catch (err) {
    alert('Error adding product: ' + err.message);
  }
});

showAll.addEventListener('click', loadAll);
showInStock.addEventListener('click', loadInStock);

// Delegate actions
tbody.addEventListener('click', async (e) => {
  const btn = e.target.closest('button');
  if (!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.action;
  if (action === 'delete') {
    if (!confirm('Delete product #' + id + '?')) return;
    try {
      const res = await fetch('/products/' + id, { method: 'DELETE' });
      if (!res.ok) throw new Error('Delete failed');
      await res.json();
      loadAll();
    } catch (err) {
      alert('Failed to delete: ' + err.message);
    }
  } else if (action === 'toggle') {
    try {
      // find current row's inStock status by reloading product
      const all = await fetchProducts('/products');
      const prod = all.find(x => String(x.id) === String(id));
      if (!prod) throw new Error('Product not found');
      const updated = { inStock: !prod.inStock };
      const res = await fetch('/products/' + id, {
        method: 'PUT',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(updated)
      });
      if (!res.ok) throw new Error('Update failed');
      await res.json();
      loadAll();
    } catch (err) {
      alert('Failed to update: ' + err.message);
    }
  }
});

// initial load
loadAll();
