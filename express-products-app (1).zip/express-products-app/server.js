const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const DATA_FILE = path.join(__dirname, 'products.json');

// Helper: ensure file exists and read
function readProducts() {
  try {
    if (!fs.existsSync(DATA_FILE)) {
      fs.writeFileSync(DATA_FILE, '[]', 'utf-8');
    }
    const data = fs.readFileSync(DATA_FILE, 'utf-8');
    return JSON.parse(data || '[]');
  } catch (err) {
    console.error('Error reading products file:', err);
    return [];
  }
}

function writeProducts(products) {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(products, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing products file:', err);
    throw err;
  }
}

// GET all products
app.get('/products', (req, res) => {
  const products = readProducts();
  res.json(products);
});

// GET in-stock products
app.get('/products/instock', (req, res) => {
  const products = readProducts();
  res.json(products.filter(p => p.inStock === true));
});

// POST add product
app.post('/products', (req, res) => {
  const { name, price, inStock } = req.body;
  if (!name || typeof price !== 'number' || typeof inStock !== 'boolean') {
    return res.status(400).json({ error: 'Invalid product data. Expected {name: string, price: number, inStock: boolean}' });
  }
  const products = readProducts();
  const newId = products.length > 0 ? Math.max(...products.map(p => p.id)) + 1 : 1;
  const newProduct = { id: newId, name, price, inStock };
  products.push(newProduct);
  writeProducts(products);
  res.status(201).json(newProduct);
});

// PUT update product
app.put('/products/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const { name, price, inStock } = req.body;
  const products = readProducts();
  const idx = products.findIndex(p => p.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Product not found' });
  if (name !== undefined) products[idx].name = name;
  if (price !== undefined) products[idx].price = price;
  if (inStock !== undefined) products[idx].inStock = inStock;
  writeProducts(products);
  res.json(products[idx]);
});

// DELETE product
app.delete('/products/:id', (req, res) => {
  const id = parseInt(req.params.id);
  const products = readProducts();
  const filtered = products.filter(p => p.id !== id);
  if (filtered.length === products.length) return res.status(404).json({ error: 'Product not found' });
  writeProducts(filtered);
  res.json({ message: `Product with id ${id} deleted successfully` });
});

// Fallback for other routes
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
